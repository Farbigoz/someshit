package CPAN::Dummy::Test::PP;

use strict;
use 5.008_005;
our $VERSION = '0.01';

1;
__END__

=encoding utf-8

=head1 NAME

CPAN::Dummy::Test::PP - Blah blah blah

=head1 SYNOPSIS

  use CPAN::Dummy::Test::PP;

=head1 DESCRIPTION

CPAN::Dummy::Test::PP is

=head1 AUTHOR

Tatsuhiko Miyagawa E<lt>miyagawa@bulknews.netE<gt>

=head1 COPYRIGHT

Copyright 2013- Tatsuhiko Miyagawa

=head1 LICENSE

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 SEE ALSO

=cut
