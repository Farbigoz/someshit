# NAME

CPAN::Dummy::Test::NonInteractive - Blah blah blah

# SYNOPSIS

    use CPAN::Dummy::Test::NonInteractive;

# DESCRIPTION

CPAN::Dummy::Test::NonInteractive is

# AUTHOR

Tatsuhiko Miyagawa <miyagawa@bulknews.net>

# COPYRIGHT

Copyright 2013- Tatsuhiko Miyagawa

# LICENSE

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# SEE ALSO
