package TestFailWithURI;

use strict;
use 5.008_001;
our $VERSION = '0.01';

1;
